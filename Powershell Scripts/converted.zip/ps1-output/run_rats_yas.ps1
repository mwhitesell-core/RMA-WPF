#-------------------------------------------------------------------------------
# File 'run_rats_yas.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'run_rats_yas'
#-------------------------------------------------------------------------------

Get-Date
&$env:cmd\application_of_rat_95_part1
&$env:cmd\application_of_rat_96_part1
&$env:cmd\application_of_rat_78_part1
