#-------------------------------------------------------------------------------
# File 'run_monthend_ar_86.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'run_monthend_ar_86'
#-------------------------------------------------------------------------------

echo ""
echo ""
echo ""
echo "CONTRACT 86"
echo ""
echo "RUN MONTHEND REPORTS AND ACCOUNTS RECEIVABLE"
echo ""
echo ""

Set-Location $env:application_production\86

&$env:COBOL r004a 86 Y

&$env:COBOL r004b

&$env:COBOL r004c Y

#lp r004

&$env:COBOL r005 86 Y

#lp r005

&$env:COBOL r011 86 Y

Get-Contents r011 | Out-Printer

&$env:COBOL r012 86 Y

#lp r012

&$env:COBOL r013 86 Y

#lp r013

&$env:COBOL r051a 86 Y

&$env:COBOL r051b

&$env:COBOL r051c

#lp r051ca

&$env:COBOL r051b

&$env:COBOL r051c

Get-Contents r051cb | Out-Printer

&$env:COBOL r070a 86 Y Y

&$env:COBOL r070b

&$env:COBOL r070c N

#lp r070_86
