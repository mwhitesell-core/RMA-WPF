#-------------------------------------------------------------------------------
# File 't4a_addrlabels5.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 't4a_addrlabels5'
#-------------------------------------------------------------------------------

&$env:QUIZ t4a_addrlabels_1 ${1} ${2} ${3} ${4} ${5}
&$env:QUIZ t4a_addrlabels_2
&$env:QUIZ t4a_addrlabels_3 "sort on doc-ohip-nbr on doc-full-part-ind on doc-nbr"
