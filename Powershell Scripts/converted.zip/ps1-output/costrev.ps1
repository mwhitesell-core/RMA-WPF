#-------------------------------------------------------------------------------
# File 'costrev.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'costrev'
#-------------------------------------------------------------------------------

&$env:QUIZ costrev
&$env:QUIZ costrev22to48
&$env:QUIZ costrev60
&$env:QUIZ costrev69
&$env:QUIZ costrev70
&$env:QUIZ costrev78to96
