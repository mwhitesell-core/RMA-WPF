#-------------------------------------------------------------------------------
# File 'recoverf001_all.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'recoverf001_all'
#-------------------------------------------------------------------------------

echo "Recover the batch control file"
echo ""
echo "No one must be accessing"
echo "the batch control and claims file"
echo "for the clinic being processed"
echo ""
echo ""
Get-Date
echo ""
echo "Hit NEWLINE to continue ..."
&$garbage = Read-Host

&$env:COBOL u991 22 N !

&$env:COBOL u991 23 N !

&$env:COBOL u991 24 N !

&$env:COBOL u991 25 N !

&$env:COBOL u991 26 N !

&$env:COBOL u991 30 N !

&$env:COBOL u991 31 N !

&$env:COBOL u991 32 N !

&$env:COBOL u991 33 N !

&$env:COBOL u991 34 N !

&$env:COBOL u991 35 N !

&$env:COBOL u991 36 N !

&$env:COBOL u991 37 N !

&$env:COBOL u991 41 N !

&$env:COBOL u991 42 N !

&$env:COBOL u991 43 N !

&$env:COBOL u991 44 N !

&$env:COBOL u991 45 N !

&$env:COBOL u991 46 N !

&$env:COBOL u991 48 N !

&$env:COBOL u991 60 N !

&$env:COBOL u991 70 N !

&$env:COBOL u991 78 N !

&$env:COBOL u991 79 N !

&$env:COBOL u991 80 N !

&$env:COBOL u991 82 N !

&$env:COBOL u991 84 N !

&$env:COBOL u991 86 N !

&$env:COBOL u991 68 N !

&$env:COBOL u991 69 N !

&$env:COBOL u991 87 N !

&$env:COBOL u991 88 N !

&$env:COBOL u991 89 N !

&$env:COBOL u991 91 N !

&$env:COBOL u991 92 N !

&$env:COBOL u991 93 N !

&$env:COBOL u991 94 N !

&$env:COBOL u991 95 N !

&$env:COBOL u991 96 N !

&$env:COBOL u991 98 N !

echo ""
Get-Date
echo ""
#lp u991
