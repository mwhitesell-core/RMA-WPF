#-------------------------------------------------------------------------------
# File 'news_email.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'news_email'
#-------------------------------------------------------------------------------

Set-Location $Env:root\alpha\rmabill\rmabill101c\production

echo "Start Time of $env:cmd\portal_reports is $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')"

&$env:QUIZ newsemail

echo "End Time of $env:cmd\portal_reports is $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')"
