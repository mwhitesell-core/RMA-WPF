#-------------------------------------------------------------------------------
# File 'verify_payroll_ok_to_run_nolonger_needed.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'verify_payroll_ok_to_run_nolonger_needed'
#-------------------------------------------------------------------------------

echo "Running verify_payroll_ok_to_run ..."
echo ""
Get-Date
echo ""
Remove-Item u100.txt

&$env:QTP u100
##quiz auto=$obj/u100.qzc -comment by MC on 2009/oct/06
&$env:QUIZ u100
echo "The following report should be blank - otherwise DONT run payoll!"
Get-Contents u100.txt
