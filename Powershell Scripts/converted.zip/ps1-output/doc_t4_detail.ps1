#-------------------------------------------------------------------------------
# File 'doc_t4_detail.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'doc_t4_detail'
#-------------------------------------------------------------------------------

echo ""
echo "Create Doctor T4 Reports"
echo ""

Set-Location $env:application_production
Remove-Item r150*.sf* *> $null

&$env:QTP r150a_detail 201601 201606 201507 201513

&$env:QUIZ r150d_detail
