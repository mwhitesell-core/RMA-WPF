#-------------------------------------------------------------------------------
# File 'batch_create_new_doctors.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'batch_create_new_doctors'
#-------------------------------------------------------------------------------

Remove-Item newdoc.ls *> $null
&$init = [scriptblock]::Create("{ Set-Location `"$(Get-Location)`" }")
Start-Job -Name "batch_create_new_doctors" -InitializationScript $init -ScriptBlock {
  & $env:cmd\create_new_doctors *> newdoc.ls
}
exit
