#-------------------------------------------------------------------------------
# File 'clinic26_g040.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'clinic26_g040'
#-------------------------------------------------------------------------------

Set-Location $Env:root\alpha\rmabill\rmabill101c\production

Remove-Item g040.txt *> $null

echo "Start Time is $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')"

&$env:QTP g040_code 201704

&$env:QUIZ g040_code

Get-Contents g040.txt | Out-Printer

echo "End Time is $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')"
