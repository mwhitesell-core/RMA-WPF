#-------------------------------------------------------------------------------
# File 'tape_to_ohip.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'tape_to_ohip'
#-------------------------------------------------------------------------------

. $env:cmd\ohip_convert_copy_to_tape
