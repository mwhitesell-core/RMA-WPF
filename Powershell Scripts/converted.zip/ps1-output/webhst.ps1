#-------------------------------------------------------------------------------
# File 'webhst.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'webhst'
#-------------------------------------------------------------------------------

# file: gsttax - upload gsttax to f113 in payroll
# 2007/jan/09 b.e. added new param to u132 call
&$env:cmd\u132 100 $1 DC
echo "Running webhst ..."
&$env:QUIZ webhst
echo "Done .. paging webhst.txt report"
Get-Contents webhst.txt
