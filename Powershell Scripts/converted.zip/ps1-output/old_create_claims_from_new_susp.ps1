#-------------------------------------------------------------------------------
# File 'old_create_claims_from_new_susp.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'old_create_claims_from_new_susp'
#-------------------------------------------------------------------------------

&$env:QTP u708
&$env:QTP newu706a
#cobrun $obj/u706b
&$env:QUIZ r709a
&$env:QUIZ r709b
Get-Contents r709b.txt | Out-Printer
Get-Contents r709a.txt | Out-Printer
