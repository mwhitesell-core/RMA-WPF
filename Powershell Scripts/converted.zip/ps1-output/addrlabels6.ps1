#-------------------------------------------------------------------------------
# File 'addrlabels6.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'addrlabels6'
#-------------------------------------------------------------------------------

&$env:QUIZ addrlabels "sort on doc-dept on doc-full-part-ind on doc-name on doc-inits" ${1} ${2} ${3} ${4}
