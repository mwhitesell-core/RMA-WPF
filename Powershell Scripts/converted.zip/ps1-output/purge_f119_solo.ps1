#-------------------------------------------------------------------------------
# File 'purge_f119_solo.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'purge_f119_solo'
#-------------------------------------------------------------------------------

#  PURGE f119_history file
#
#  2009/07/07   Change dates to 200101 to 200113 and EP 2001 to 2001
#  2010/07/06   Change dates to 200201 to 200213 and EP 2002 to 2002
#  2011/06/07   Change dates to 200301 to 200313 and EP 2003 to 2003
#  2014/Jun/11  yas change purge date to 2006 
#  2015/Jul/04  yas change purge date to 2007

Set-Location $Env:root\charly\purge\solo

Remove-Item $pb_prod\purgef119_solo.log *> $null

echo "Purge f119-history -  STARTING - $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')" > $pb_prod\purgef119_solo.log

&$env:QTP purge_unlof119_history 200801 200813 >> $pb_prod\purgef119_solo.log 2> $pb_prod\purgef119_solo.log


Set-Location $pb_data

Move-Item -Force f119_doc_ytd_history.dat $Env:root\charly\purge\solo\f119_doc_ytd_history.dat
Move-Item -Force f119_doc_ytd_history.idx $Env:root\charly\purge\solo\f119_doc_ytd_history.idx

echo "--- create files ---"
$pipedInput = @"
create file f119-doctor-ytd-history
"@

$pipedInput | qutil++

Set-Location $Env:root\charly\purge\solo

&$env:QTP purge_relof119_history >> $pb_prod\purgef119_solo.log 2> $pb_prod\purgef119_solo.log


echo "Purge f119-history - ENDING - $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')" >> $pb_prod\purgef119_solo.log
