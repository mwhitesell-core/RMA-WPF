#-------------------------------------------------------------------------------
# File 'payroll3.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'payroll3'
#-------------------------------------------------------------------------------

&$env:QUIZ payrolllist "sort on doc-clinic-nbr on doc-dept on doc-nbr" ${1} ${2} ${3}
