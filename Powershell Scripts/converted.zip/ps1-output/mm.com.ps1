#-------------------------------------------------------------------------------
# File 'mm.com.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'mm.com'
#-------------------------------------------------------------------------------

# mail merge pgm

&$env:QUIZ mm_a
&$env:QUIZ mm_b
&$env:QUIZ mm_c
Get-Content mm_a.sf, mm_b.sf, mm_c.sf > mm.rtf
echo ""
echo "Download 'mm.rtf' for mail merge secondary (data) file ..."
