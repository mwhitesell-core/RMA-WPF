#-------------------------------------------------------------------------------
# File 'update_batch_status_96.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'update_batch_status_96'
#-------------------------------------------------------------------------------

Set-Location $env:application_production\96
Remove-Item status.ls
#batch << BATCH_EXIT
&$env:cmd\status96 *> status.ls
#BATCH_EXIT
