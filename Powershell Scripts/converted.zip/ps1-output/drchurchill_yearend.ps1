#-------------------------------------------------------------------------------
# File 'drchurchill_yearend.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'drchurchill_yearend'
#-------------------------------------------------------------------------------

&$env:QTP f050ma1_yearend
&$env:QTP f050_bi
