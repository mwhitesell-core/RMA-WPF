#-------------------------------------------------------------------------------
# File 'clinic88_g313.com.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'clinic88_g313.com'
#-------------------------------------------------------------------------------

&$env:cmd\clinic88_g313 > clinic88_g313.log
