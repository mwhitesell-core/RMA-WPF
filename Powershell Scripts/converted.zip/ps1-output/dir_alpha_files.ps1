#-------------------------------------------------------------------------------
# File 'dir_alpha_files.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'dir_alpha_files'
#-------------------------------------------------------------------------------

Set-Location $Env:root\alpha\rmabill\rmabill100\data
