#-------------------------------------------------------------------------------
# File 'run_monthend_ar_46.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'run_monthend_ar_46'
#-------------------------------------------------------------------------------

echo ""
echo ""
echo ""
echo "CONTRACT 46"
echo ""
echo "RUN MONTHEND REPORTS AND ACCOUNTS RECEIVABLE"
echo ""
echo ""

Set-Location $env:application_production\46

&$env:COBOL r004a 46 Y

&$env:COBOL r004b

&$env:COBOL r004c Y

#lp r004

&$env:COBOL r005 46 Y

#lp r005

&$env:COBOL r011 46 Y

#lp r011

&$env:COBOL r012 46 Y

#lp r012

&$env:COBOL r013 46 Y

#lp r013

&$env:COBOL r051a 46 Y

&$env:COBOL r051b

&$env:COBOL r051c

#lp r051ca

&$env:COBOL r051b

&$env:COBOL r051c

#lp r051cb

&$env:COBOL r070a 46 Y Y

&$env:COBOL r070b

&$env:COBOL r070c N

#lp r070_46
