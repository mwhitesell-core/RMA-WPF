#-------------------------------------------------------------------------------
# File 'tmpflgo.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'tmpflgo'
#-------------------------------------------------------------------------------

# CONVERSION ERROR (unexpected, #1): Not 2 or 3 keywords in simple assignment.
# pb_obj=/alpha/rmabill/rmabill101c/obj; export pb_obj
