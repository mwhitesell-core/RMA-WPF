#-------------------------------------------------------------------------------
# File 'update_f050_f051_f060.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'update_f050_f051_f060'
#-------------------------------------------------------------------------------

# update_f050_f051_f060
#    update doctor revenue, doctor cash, cheque register files
#    to change the doctor's department. If a 3rd parameter (date) is
#    passed then only records on/after that date are changed.
#
#  this job tests to see if the 'indicator' file exists before it runs - if
#  and then removes it after running


&$macros = "$env:root\\macros"
&$audit_file = "$env:root\\audit\\applications.audit"
&$RELNOTES = "$env:root\relnotes"

# CONVERSION ERROR (expected, #14): Korn shell setup.
# ENV=$macros/sys.kshrc; export ENV

. $macros\globals
. $macros\toolkit

# POWERHOUSE setup
# CONVERSION ERROR (expected, #20): Cognos setup.
# COGNOS=/usr/cognos                              ; export COGNOS

# CONVERSION ERROR (expected, #22): umask is involved.
# umask 002

# LIVE LIVE LIVE LIVE LIVE LIVE LIVE LIVE LIVE LIVE LIVE LIVE LIVE LIVE LIVE
. $macros\setup_rmabill.com  101c
# LIVE LIVE LIVE LIVE LIVE LIVE LIVE LIVE LIVE LIVE LIVE LIVE LIVE LIVE LIVE

Set-Location $pb_data

if (Test-Path batch_update_f050_f051_f060.flg)
{
   echo " "
   echo "Department Change 'indicator' file FOUND  $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')"

   Set-Location $env:application_production
#   qtp auto=$obj/u901.qtc < $pb_data/batch_update_f050_f051_f060.flg \
#                        >> /beta/rmabill/rmabill101c/production/u901.log
#   qtp auto=$obj/u901.qtc < $pb_data/batch_update_f050_f051_f060.flg \
#                        >> /dyad/rmabill101c/production/u901.log
Get-Content $pb_data\batch_update_f050_f051_f060.flg |   $env:QTP u901 `
  >> $Env:root\dyad\rmabill\rmabill101c\production\u901.log
   echo "Processing completed $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')"

   Set-Location $pb_data
#  (remove the 3 parameter lines from .flg file and rebuild new parm file if
#   more transactions found)
Get-Content batch_update_f050_f051_f060.flg |   awk++ $env:cmd\batch_update_f050.awk
   mv batch_update_f050_f051_f060.flg batch_update_f050_f051_f060.run.$(Get-Date -uformat "%Y_%m_%d_time_%H:%M")
#  (if more transactions then rename to correct parm file and recall this macro)
   echo "testing if more parms"
   if (Test-Path batch_update_f050_f051_f060.flg.new)
   {
      echo "parms found"
      Move-Item -Force batch_update_f050_f051_f060.flg.new batch_update_f050_f051_f060.flg
      echo "recalling this macro"
            &$env:cmd\update_f050_f051_f060
   } else {
        echo "NO more parms $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')"
   }
} else {
   echo "Department Change 'indicator' file NOT found  $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')"
}
