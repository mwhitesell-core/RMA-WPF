#-------------------------------------------------------------------------------
# File 'doc_rev_yearly_roll.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'doc_rev_yearly_roll'
#-------------------------------------------------------------------------------

&$init = [scriptblock]::Create("{ Set-Location `"$(Get-Location)`" }")
Start-Job -Name "doc_rev_yearly_roll" -InitializationScript $init -ScriptBlock {
  & $env:QTP purge_f050_f051 *> roll.ls
  & Get-Contents roll.ls | Out-Printer
}
