#-------------------------------------------------------------------------------
# File 'update_batch_status_60.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'update_batch_status_60'
#-------------------------------------------------------------------------------

Set-Location $env:application_production\60
Remove-Item status.ls
#batch << BATCH_EXIT
&$env:cmd\status60 *> status.ls
#BATCH_EXIT
