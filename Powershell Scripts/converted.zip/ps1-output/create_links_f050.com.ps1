#-------------------------------------------------------------------------------
# File 'create_links_f050.com.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'create_links_f050.com'
#-------------------------------------------------------------------------------

# CONVERSION ERROR (expected, #1): Symbolic link creation.
# ln -s f050_doc_revenue_mstr   f050_doc_revenue_mstr.dat
