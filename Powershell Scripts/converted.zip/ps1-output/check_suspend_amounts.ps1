#-------------------------------------------------------------------------------
# File 'check_suspend_amounts.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'check_suspend_amounts'
#-------------------------------------------------------------------------------

Remove-Item r717.txt *> $null

&$env:QUIZ r717

Get-Contents r717.txt | Out-Printer
