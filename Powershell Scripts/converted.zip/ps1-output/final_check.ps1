#-------------------------------------------------------------------------------
# File 'final_check.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'final_check'
#-------------------------------------------------------------------------------

&$env:cmd\dump_tech
&$env:cmd\resubmits
&$env:cmd\suffix
&$env:cmd\check_suspend_dtl
&$env:cmd\check_suspend_amounts
