#-------------------------------------------------------------------------------
# File 'r011before.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'r011before'
#-------------------------------------------------------------------------------

Move-Item -Force r011_22 r011_22_before
Move-Item -Force r011_43 r011_43_before
Move-Item -Force r011_80 r011_80_before
Move-Item -Force r011_81 r011_81_before
Move-Item -Force r011_82 r011_82_before
Move-Item -Force r011_83 r011_83_before
Move-Item -Force r011_84 r011_84_before
Move-Item -Force r011_91 r011_91_before
Move-Item -Force r011_92 r011_92_before
Move-Item -Force r011_93 r011_93_before
Move-Item -Force r011_94 r011_94_before
Move-Item -Force r011_95 r011_95_before
Move-Item -Force r011_96 r011_96_before
Move-Item -Force r011_60 r011_60_before
