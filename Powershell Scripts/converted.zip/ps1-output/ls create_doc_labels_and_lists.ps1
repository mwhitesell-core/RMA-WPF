#-------------------------------------------------------------------------------
# File 'ls create_doc_labels_and_lists.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'ls create_doc_labels_and_lists'
#-------------------------------------------------------------------------------


