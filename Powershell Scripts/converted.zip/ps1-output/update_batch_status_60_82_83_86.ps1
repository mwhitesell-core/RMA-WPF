#-------------------------------------------------------------------------------
# File 'update_batch_status_60_82_83_86.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'update_batch_status_60_82_83_86'
#-------------------------------------------------------------------------------

Get-Date
&$env:cmd\update_batch_status_60
&$env:cmd\update_batch_status_82
&$env:cmd\update_batch_status_86
&$env:cmd\update_batch_status_70
Get-Date
