#-------------------------------------------------------------------------------
# File 'run_monthend_ar_26.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'run_monthend_ar_26'
#-------------------------------------------------------------------------------

echo ""
echo ""
echo ""
echo "CONTRACT 26"
echo ""
echo "RUN MONTHEND REPORTS AND ACCOUNTS RECEIVABLE"
echo ""
echo ""

Set-Location $env:application_production\26

&$env:COBOL r004a 26 Y

&$env:COBOL r004b

&$env:COBOL r004c Y

#lp r004

&$env:COBOL r005 26 Y

#lp r005

&$env:COBOL r011 26 Y

Get-Contents r011 | Out-Printer

&$env:COBOL r012 26 Y

#lp r012

&$env:COBOL r013 26 Y

#lp r013

&$env:COBOL r051a 26 Y

&$env:COBOL r051b

&$env:COBOL r051c

#lp r051ca

&$env:COBOL r051b

&$env:COBOL r051c

#lp r051cb

&$env:COBOL r070a 26 Y Y

&$env:COBOL r070b

&$env:COBOL r070c N

#lp r070_26
