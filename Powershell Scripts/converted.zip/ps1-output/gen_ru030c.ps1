#-------------------------------------------------------------------------------
# File 'gen_ru030c.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'gen_ru030c'
#-------------------------------------------------------------------------------

&$env:QUIZ r030f1
&$env:QUIZ r030f2

#lp ru030c.txt
