#-------------------------------------------------------------------------------
# File 'rerun_rat_reports.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'rerun_rat_reports'
#-------------------------------------------------------------------------------

# 2016/Apr/06    recover the missing r997.txt in each clinic, suspect user has run
#                the macro $cmd/print_rats twice

Get-Content r997f.txt >> r997.txt
Get-Content r997g.txt >> r997.txt
Get-Content r997h.txt >> r997.txt
Get-Content r997i.txt >> r997.txt
Get-Content r997j.txt >> r997.txt
Get-Content r997k.txt >> r997.txt
Get-Content r997_total.txt >> r997.txt
