#-------------------------------------------------------------------------------
# File 'f050hist.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'f050hist'
#-------------------------------------------------------------------------------

&$env:QUIZ audit_f050hist
#lp audit_f050hist.txt
