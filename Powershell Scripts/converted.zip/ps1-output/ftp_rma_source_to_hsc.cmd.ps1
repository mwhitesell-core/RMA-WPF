#-------------------------------------------------------------------------------
# File 'ftp_rma_source_to_hsc.cmd.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'ftp_rma_source_to_hsc.cmd'
#-------------------------------------------------------------------------------

# CONVERSION ERROR (unexpected, #1): Unknown command.
# ftp -v blue <<  FTP_EXIT
