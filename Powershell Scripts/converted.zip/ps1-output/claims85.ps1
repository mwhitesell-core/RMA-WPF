#-------------------------------------------------------------------------------
# File 'claims85.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'claims85'
#-------------------------------------------------------------------------------

&$env:QTP claims85_a
&$env:QUIZ claims85_b
