#-------------------------------------------------------------------------------
# File 'r011_60.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'r011_60'
#-------------------------------------------------------------------------------

&$env:QUIZ r011a
&$env:QUIZ r011b
&$env:QUIZ r011c

Get-Content r011b.txt, r011c.txt >> r011a.txt
Move-Item -Force r011a.txt r011_60
