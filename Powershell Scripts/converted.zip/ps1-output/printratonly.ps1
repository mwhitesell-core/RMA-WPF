#-------------------------------------------------------------------------------
# File 'printratonly.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'printratonly'
#-------------------------------------------------------------------------------

Set-Location $env:application_production\61
Get-Contents ru030a_61 | Out-Printer
Get-Contents ru030b_61 | Out-Printer
Get-Contents ru030c_61 | Out-Printer
Get-Contents ru030d_61 | Out-Printer
Get-Contents ru030e_61 | Out-Printer

Set-Location $env:application_production\62
Get-Contents ru030a_62 | Out-Printer
Get-Contents ru030b_62 | Out-Printer
Get-Contents ru030c_62 | Out-Printer
Get-Contents ru030d_62 | Out-Printer
Get-Contents ru030e_62 | Out-Printer

Set-Location $env:application_production\63
Get-Contents ru030a_63 | Out-Printer
Get-Contents ru030b_63 | Out-Printer
Get-Contents ru030c_63 | Out-Printer
Get-Contents ru030d_63 | Out-Printer
Get-Contents ru030e_63 | Out-Printer

Set-Location $env:application_production\64
Get-Contents ru030a_64 | Out-Printer
Get-Contents ru030b_64 | Out-Printer
Get-Contents ru030c_64 | Out-Printer
Get-Contents ru030d_64 | Out-Printer
Get-Contents ru030e_64 | Out-Printer

Set-Location $env:application_production\65
Get-Contents ru030a_65 | Out-Printer
Get-Contents ru030b_65 | Out-Printer
Get-Contents ru030c_65 | Out-Printer
Get-Contents ru030d_65 | Out-Printer
Get-Contents ru030e_65 | Out-Printer

Set-Location $env:application_production\66
Get-Contents ru030a_66 | Out-Printer
Get-Contents ru030b_66 | Out-Printer
Get-Contents ru030c_66 | Out-Printer
Get-Contents ru030d_66 | Out-Printer
Get-Contents ru030e_66 | Out-Printer

Set-Location $env:application_production\71
Get-Contents ru030a_71 | Out-Printer
Get-Contents ru030b_71 | Out-Printer
Get-Contents ru030c_71 | Out-Printer
Get-Contents ru030d_71 | Out-Printer
Get-Contents ru030e_71 | Out-Printer

Set-Location $env:application_production\72
Get-Contents ru030a_72 | Out-Printer
Get-Contents ru030b_72 | Out-Printer
Get-Contents ru030c_72 | Out-Printer
Get-Contents ru030d_72 | Out-Printer
Get-Contents ru030e_72 | Out-Printer

Set-Location $env:application_production\73
Get-Contents ru030a_73 | Out-Printer
Get-Contents ru030b_73 | Out-Printer
Get-Contents ru030c_73 | Out-Printer
Get-Contents ru030d_73 | Out-Printer
Get-Contents ru030e_73 | Out-Printer

Set-Location $env:application_production\74
Get-Contents ru030a_74 | Out-Printer
Get-Contents ru030b_74 | Out-Printer
Get-Contents ru030c_74 | Out-Printer
Get-Contents ru030d_74 | Out-Printer
Get-Contents ru030e_74 | Out-Printer

Set-Location $env:application_production\75
Get-Contents ru030a_75 | Out-Printer
Get-Contents ru030b_75 | Out-Printer
Get-Contents ru030c_75 | Out-Printer
Get-Contents ru030d_75 | Out-Printer
Get-Contents ru030e_75 | Out-Printer

Set-Location $env:application_production
Get-Contents ru030a_22 | Out-Printer
Get-Contents ru030b_22 | Out-Printer
Get-Contents ru030c_22 | Out-Printer
Get-Contents ru030d_22 | Out-Printer
Get-Contents ru030e_22 | Out-Printer

Set-Location $env:application_production\23
Get-Contents ru030a_23 | Out-Printer
Get-Contents ru030b_23 | Out-Printer
Get-Contents ru030c_23 | Out-Printer
Get-Contents ru030d_23 | Out-Printer
Get-Contents ru030e_23 | Out-Printer

Set-Location $env:application_production\24
Get-Contents ru030a_24 | Out-Printer
Get-Contents ru030b_24 | Out-Printer
Get-Contents ru030c_24 | Out-Printer
Get-Contents ru030d_24 | Out-Printer
Get-Contents ru030e_24 | Out-Printer

Set-Location $env:application_production\25
Get-Contents ru030a_25 | Out-Printer
Get-Contents ru030b_25 | Out-Printer
Get-Contents ru030c_25 | Out-Printer
Get-Contents ru030d_25 | Out-Printer
Get-Contents ru030e_25 | Out-Printer

Set-Location $env:application_production\26
Get-Contents ru030a_26 | Out-Printer
Get-Contents ru030b_26 | Out-Printer
Get-Contents ru030c_26 | Out-Printer
Get-Contents ru030d_26 | Out-Printer
Get-Contents ru030e_26 | Out-Printer

Set-Location $env:application_production\30
Get-Contents ru030a_30 | Out-Printer
Get-Contents ru030b_30 | Out-Printer
Get-Contents ru030c_30 | Out-Printer
Get-Contents ru030d_30 | Out-Printer
Get-Contents ru030e_30 | Out-Printer

Set-Location $env:application_production\31
Get-Contents ru030a_31 | Out-Printer
Get-Contents ru030b_31 | Out-Printer
Get-Contents ru030c_31 | Out-Printer
Get-Contents ru030d_31 | Out-Printer
Get-Contents ru030e_31 | Out-Printer

Set-Location $env:application_production\32
Get-Contents ru030a_32 | Out-Printer
Get-Contents ru030b_32 | Out-Printer
Get-Contents ru030c_32 | Out-Printer
Get-Contents ru030d_32 | Out-Printer
Get-Contents ru030e_32 | Out-Printer

Set-Location $env:application_production\33
Get-Contents ru030a_33 | Out-Printer
Get-Contents ru030b_33 | Out-Printer
Get-Contents ru030c_33 | Out-Printer
Get-Contents ru030d_33 | Out-Printer
Get-Contents ru030e_33 | Out-Printer

Set-Location $env:application_production\34
Get-Contents ru030a_34 | Out-Printer
Get-Contents ru030b_34 | Out-Printer
Get-Contents ru030c_34 | Out-Printer
Get-Contents ru030d_34 | Out-Printer
Get-Contents ru030e_34 | Out-Printer

Set-Location $env:application_production\35
Get-Contents ru030a_35 | Out-Printer
Get-Contents ru030b_35 | Out-Printer
Get-Contents ru030c_35 | Out-Printer
Get-Contents ru030d_35 | Out-Printer
Get-Contents ru030e_35 | Out-Printer

Set-Location $env:application_production\36
Get-Contents ru030a_36 | Out-Printer
Get-Contents ru030b_36 | Out-Printer
Get-Contents ru030c_36 | Out-Printer
Get-Contents ru030d_36 | Out-Printer
Get-Contents ru030e_36 | Out-Printer

Set-Location $env:application_production\41
Get-Contents ru030a_41 | Out-Printer
Get-Contents ru030b_41 | Out-Printer
Get-Contents ru030c_41 | Out-Printer
Get-Contents ru030d_41 | Out-Printer
Get-Contents ru030e_41 | Out-Printer

Set-Location $env:application_production\42
Get-Contents ru030a_42 | Out-Printer
Get-Contents ru030b_42 | Out-Printer
Get-Contents ru030c_42 | Out-Printer
Get-Contents ru030d_42 | Out-Printer
Get-Contents ru030e_42 | Out-Printer

Set-Location $env:application_production\43
Get-Contents ru030a_43 | Out-Printer
Get-Contents ru030b_43 | Out-Printer
Get-Contents ru030c_43 | Out-Printer
Get-Contents ru030d_43 | Out-Printer
Get-Contents ru030e_43 | Out-Printer

Set-Location $env:application_production\44
Get-Contents ru030a_44 | Out-Printer
Get-Contents ru030b_44 | Out-Printer
Get-Contents ru030c_44 | Out-Printer
Get-Contents ru030d_44 | Out-Printer
Get-Contents ru030e_44 | Out-Printer

Set-Location $env:application_production\45
Get-Contents ru030a_45 | Out-Printer
Get-Contents ru030b_45 | Out-Printer
Get-Contents ru030c_45 | Out-Printer
Get-Contents ru030d_45 | Out-Printer
Get-Contents ru030e_45 | Out-Printer

Set-Location $env:application_production\46
Get-Contents ru030a_46 | Out-Printer
Get-Contents ru030b_46 | Out-Printer
Get-Contents ru030c_46 | Out-Printer
Get-Contents ru030d_46 | Out-Printer
Get-Contents ru030e_46 | Out-Printer

Set-Location $env:application_production\37
Get-Contents ru030a_37 | Out-Printer
Get-Contents ru030b_37 | Out-Printer
Get-Contents ru030c_37 | Out-Printer
Get-Contents ru030d_37 | Out-Printer
Get-Contents ru030e_37 | Out-Printer

Set-Location $env:application_production\78
Get-Contents ru030a_78 | Out-Printer
Get-Contents ru030b_78 | Out-Printer
Get-Contents ru030c_78 | Out-Printer
Get-Contents ru030d_78 | Out-Printer
Get-Contents ru030e_78 | Out-Printer

Set-Location $env:application_production\79
Get-Contents ru030a_79 | Out-Printer
Get-Contents ru030b_79 | Out-Printer
Get-Contents ru030c_79 | Out-Printer
Get-Contents ru030d_79 | Out-Printer
Get-Contents ru030e_79 | Out-Printer

Set-Location $env:application_production\80
Get-Contents ru030a_80 | Out-Printer
Get-Contents ru030b_80 | Out-Printer
Get-Contents ru030c_80 | Out-Printer
Get-Contents ru030d_80 | Out-Printer
Get-Contents ru030e_80 | Out-Printer

Set-Location $env:application_production\82
Get-Contents ru030a_82 | Out-Printer
Get-Contents ru030b_82 | Out-Printer
Get-Contents ru030c_82 | Out-Printer
Get-Contents ru030d_82 | Out-Printer
Get-Contents ru030e_82 | Out-Printer

Set-Location $env:application_production\83
Get-Contents ru030a_83 | Out-Printer
Get-Contents ru030b_83 | Out-Printer
Get-Contents ru030c_83 | Out-Printer
Get-Contents ru030d_83 | Out-Printer
Get-Contents ru030e_83 | Out-Printer

Set-Location $env:application_production\84
Get-Contents ru030a_84 | Out-Printer
Get-Contents ru030b_84 | Out-Printer
Get-Contents ru030c_84 | Out-Printer
Get-Contents ru030d_84 | Out-Printer
Get-Contents ru030e_84 | Out-Printer

Set-Location $env:application_production\86
Get-Contents ru030a_86 | Out-Printer
Get-Contents ru030b_86 | Out-Printer
Get-Contents ru030c_86 | Out-Printer
Get-Contents ru030d_86 | Out-Printer
Get-Contents ru030e_86 | Out-Printer

Set-Location $env:application_production\87
Get-Contents ru030a_87 | Out-Printer
Get-Contents ru030b_87 | Out-Printer
Get-Contents ru030c_87 | Out-Printer
Get-Contents ru030d_87 | Out-Printer
Get-Contents ru030e_87 | Out-Printer

Set-Location $env:application_production\88
Get-Contents ru030a_88 | Out-Printer
Get-Contents ru030b_88 | Out-Printer
Get-Contents ru030c_88 | Out-Printer
Get-Contents ru030d_88 | Out-Printer
Get-Contents ru030e_88 | Out-Printer

Set-Location $env:application_production\89
Get-Contents ru030a_89 | Out-Printer
Get-Contents ru030b_89 | Out-Printer
Get-Contents ru030c_89 | Out-Printer
Get-Contents ru030d_89 | Out-Printer
Get-Contents ru030e_89 | Out-Printer

Set-Location $env:application_production\91
Get-Contents ru030a_91 | Out-Printer
Get-Contents ru030b_91 | Out-Printer
Get-Contents ru030c_91 | Out-Printer
Get-Contents ru030d_91 | Out-Printer
Get-Contents ru030e_91 | Out-Printer

Set-Location $env:application_production\92
Get-Contents ru030a_92 | Out-Printer
Get-Contents ru030b_92 | Out-Printer
Get-Contents ru030c_92 | Out-Printer
Get-Contents ru030d_92 | Out-Printer
Get-Contents ru030e_92 | Out-Printer

Set-Location $env:application_production\93
Get-Contents ru030a_93 | Out-Printer
Get-Contents ru030b_93 | Out-Printer
Get-Contents ru030c_93 | Out-Printer
Get-Contents ru030d_93 | Out-Printer
Get-Contents ru030e_93 | Out-Printer

Set-Location $env:application_production\94
Get-Contents ru030a_94 | Out-Printer
Get-Contents ru030b_94 | Out-Printer
Get-Contents ru030c_94 | Out-Printer
Get-Contents ru030d_94 | Out-Printer
Get-Contents ru030e_94 | Out-Printer

Set-Location $env:application_production\95
Get-Contents ru030a_95 | Out-Printer
Get-Contents ru030b_95 | Out-Printer
Get-Contents ru030c_95 | Out-Printer
Get-Contents ru030d_95 | Out-Printer
Get-Contents ru030e_95 | Out-Printer

Set-Location $env:application_production\96
Get-Contents ru030a_96 | Out-Printer
Get-Contents ru030b_96 | Out-Printer
Get-Contents ru030c_96 | Out-Printer
Get-Contents ru030d_96 | Out-Printer
Get-Contents ru030e_96 | Out-Printer

Set-Location $env:application_production\68
Get-Contents ru030a_68 | Out-Printer
Get-Contents ru030b_68 | Out-Printer
Get-Contents ru030c_68 | Out-Printer
Get-Contents ru030d_68 | Out-Printer
Get-Contents ru030e_68 | Out-Printer

Set-Location $env:application_production\69
Get-Contents ru030a_69 | Out-Printer
Get-Contents ru030b_69 | Out-Printer
Get-Contents ru030c_69 | Out-Printer
Get-Contents ru030d_69 | Out-Printer
Get-Contents ru030e_69 | Out-Printer
