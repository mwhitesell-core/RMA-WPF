#-------------------------------------------------------------------------------
# File 'r004_all.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'r004_all'
#-------------------------------------------------------------------------------

&$env:COBOL r004a 22 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_22

&$env:COBOL r004a 31 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_31

&$env:COBOL r004a 32 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_32

&$env:COBOL r004a 33 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_33

&$env:COBOL r004a 34 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_34

&$env:COBOL r004a 36 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_36

&$env:COBOL r004a 41 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_41

&$env:COBOL r004a 42 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_42

&$env:COBOL r004a 43 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_43

&$env:COBOL r004a 44 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_45

&$env:COBOL r004a 46 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_46

&$env:COBOL r004a 48 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_48

&$env:COBOL r004a 61 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_61

&$env:COBOL r004a 62 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_62

&$env:COBOL r004a 63 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_63

&$env:COBOL r004a 64 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_64


&$env:COBOL r004a 65 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_65

&$env:COBOL r004a 80 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_80

&$env:COBOL r004a 82 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_82

&$env:COBOL r004a 84 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_84

&$env:COBOL r004a 86 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_86

&$env:COBOL r004a 91 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_91

&$env:COBOL r004a 92 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_92

&$env:COBOL r004a 93 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_93

&$env:COBOL r004a 94 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_94


&$env:COBOL r004a 95 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_95

&$env:COBOL r004a 96 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_96

&$env:COBOL r004a 98 Y

&$env:COBOL r004b

&$env:COBOL r004c Y
Move-Item -Force r004 r004_98
