#-------------------------------------------------------------------------------
# File 'print_rats.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'print_rats'
#-------------------------------------------------------------------------------

&$env:cmd\application_of_rat_60_part2
&$env:cmd\application_of_rat_70_part2
&$env:cmd\appl_of_rat_22_to_48_part2
&$env:cmd\appl_of_rat_80_to_96_part2
