#-------------------------------------------------------------------------------
# File 'john1.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'john1'
#-------------------------------------------------------------------------------

&$env:QUIZ john
&$env:QUIZ john1
&$env:QUIZ john3doc
&$env:QUIZ john1dept
&$env:QUIZ johndept
#lp john.ls
