#-------------------------------------------------------------------------------
# File 'fix_claims.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'fix_claims'
#-------------------------------------------------------------------------------

quick++ $obj\fixf002_hdr
