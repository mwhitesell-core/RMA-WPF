#-------------------------------------------------------------------------------
# File 'suspense_download.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'suspense_download'
#-------------------------------------------------------------------------------

# suspense_download
&$env:QTP unlof002_susp_addr
&$env:QTP unlof002_susp_hdr
&$env:QTP unlof002_susp_dtl
