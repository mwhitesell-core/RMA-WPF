#-------------------------------------------------------------------------------
# File 'f096_pay_code.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'f096_pay_code'
#-------------------------------------------------------------------------------

# setdict rma
# 99/oct/10 B.E. - changed terminal type
#quick auto=$pb_obj/m902.qkc term=D461
quick++ $pb_obj\m902
