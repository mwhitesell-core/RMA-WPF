#-------------------------------------------------------------------------------
# File 'yas40.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'yas40'
#-------------------------------------------------------------------------------

echo " --- r005 (COBOL) --- "
&$env:COBOL r005 22 Y

#lp r005

echo " --- r011 (COBOL) --- "
&$env:COBOL r011 22 Y

#lp r011


echo " --- r012 (COBOL) --- "
&$env:COBOL r012 22 Y

#lp r012

echo " --- r013 (COBOL) --- "
&$env:COBOL r013 22 Y

#lp r013
