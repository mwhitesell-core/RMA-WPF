#-------------------------------------------------------------------------------
# File 'r124b_s01tos17.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'r124b_s01tos17'
#-------------------------------------------------------------------------------

echo "---  and  r124b_S01 to S17 -- PRINT VERSION  ---"
&$env:QUIZ r124b_ `
  "and sel if    doc-nbr = `"S01`"       &            or doc-nbr = `"S02`"       &            or doc-nbr = `"S03`"       &            or doc-nbr = `"S04`"       &            or doc-nbr = `"S05`"       &            or doc-nbr = `"S06`"       &            or doc-nbr = `"S07`"       &            or doc-nbr = `"S08`"       &            or doc-nbr = `"S09`"       &            or doc-nbr = `"S10`"       &            or doc-nbr = `"S11`"       &            or doc-nbr = `"S12`"       &            or doc-nbr = `"S13`"       &            or doc-nbr = `"S14`"       &            or doc-nbr = `"S15`"       &            or doc-nbr = `"S16`"       &            or doc-nbr = `"S17`"       &" `
  PRINT DOC
