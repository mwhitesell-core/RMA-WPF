#-------------------------------------------------------------------------------
# File 'check_ext.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'check_ext'
#-------------------------------------------------------------------------------

Set-Location $Env:root\alpha\rmabill\rmabill101c\production

Get-ChildItem *ext*txt
