#-------------------------------------------------------------------------------
# File 'generate_ru030c_dtl.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'generate_ru030c_dtl'
#-------------------------------------------------------------------------------

Get-Date

#cd $application_production
#$cmd/gen_ru030c
#cd   $application_production/23 
#$cmd/gen_ru030c
#cd   $application_production/31 
#$cmd/gen_ru030c
Set-Location $env:application_production\32
&$env:cmd\gen_ru030c
Set-Location $env:application_production\33
&$env:cmd\gen_ru030c
Set-Location $env:application_production\34
&$env:cmd\gen_ru030c
Set-Location $env:application_production\35
&$env:cmd\gen_ru030c
Set-Location $env:application_production\36
&$env:cmd\gen_ru030c
Set-Location $env:application_production\37
&$env:cmd\gen_ru030c
Set-Location $env:application_production\41
&$env:cmd\gen_ru030c
Set-Location $env:application_production\42
&$env:cmd\gen_ru030c
Set-Location $env:application_production\43
&$env:cmd\gen_ru030c
Set-Location $env:application_production\44
&$env:cmd\gen_ru030c
Set-Location $env:application_production\45
&$env:cmd\gen_ru030c
Set-Location $env:application_production\46
&$env:cmd\gen_ru030c
Set-Location $env:application_production\61
&$env:cmd\gen_ru030c
Set-Location $env:application_production\62
&$env:cmd\gen_ru030c
Set-Location $env:application_production\63
&$env:cmd\gen_ru030c
Set-Location $env:application_production\64
&$env:cmd\gen_ru030c
Set-Location $env:application_production\66
&$env:cmd\gen_ru030c
Set-Location $env:application_production\71
&$env:cmd\gen_ru030c
Set-Location $env:application_production\72
&$env:cmd\gen_ru030c
Set-Location $env:application_production\73
&$env:cmd\gen_ru030c
Set-Location $env:application_production\74
&$env:cmd\gen_ru030c
Set-Location $env:application_production\75
&$env:cmd\gen_ru030c
Set-Location $env:application_production\78
&$env:cmd\gen_ru030c
Set-Location $env:application_production\79
&$env:cmd\gen_ru030c
Set-Location $env:application_production\80
&$env:cmd\gen_ru030c
Set-Location $env:application_production\82
&$env:cmd\gen_ru030c
Set-Location $env:application_production\84
&$env:cmd\gen_ru030c
Set-Location $env:application_production\86
&$env:cmd\gen_ru030c
Set-Location $env:application_production\87
&$env:cmd\gen_ru030c
Set-Location $env:application_production\88
&$env:cmd\gen_ru030c
Set-Location $env:application_production\91
&$env:cmd\gen_ru030c
Set-Location $env:application_production\92
&$env:cmd\gen_ru030c
Set-Location $env:application_production\93
&$env:cmd\gen_ru030c
Set-Location $env:application_production\94
&$env:cmd\gen_ru030c
Set-Location $env:application_production\95
&$env:cmd\gen_ru030c
Set-Location $env:application_production\96
&$env:cmd\gen_ru030c

Get-Date
