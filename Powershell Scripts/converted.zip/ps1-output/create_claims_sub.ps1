#-------------------------------------------------------------------------------
# File 'create_claims_sub.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'create_claims_sub'
#-------------------------------------------------------------------------------

&$env:QTP u708
&$env:QTP u706a
&$env:COBOL u706b
&$env:QUIZ r709a
&$env:QUIZ r709b
Get-Contents r709b.txt | Out-Printer
Get-Contents r709a.txt | Out-Printer
