#-------------------------------------------------------------------------------
# File 'copy_f113_101c_solo.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'copy_f113_101c_solo'
#-------------------------------------------------------------------------------

Set-Location $Env:root\alpha\rmabill\rmabill101c\data

Copy-Item f113_default_comp.dat $Env:root\alpha\rmabill\rmabill101c\data\backup
Copy-Item f113_default_comp.idx $Env:root\alpha\rmabill\rmabill101c\data\backup
Copy-Item f113_default_comp_upload_driver.dat $Env:root\alpha\rmabill\rmabill101c\data\backup
Copy-Item f113_default_comp_upload_driver.idx $Env:root\alpha\rmabill\rmabill101c\data\backup

Set-Location $Env:root\alpha\rmabill\rmabillsolo\data

Copy-Item f113_default_comp.dat $Env:root\alpha\rmabill\rmabillsolo\data\backup
Copy-Item f113_default_comp.idx $Env:root\alpha\rmabill\rmabillsolo\data\backup

Set-Location $Env:root\alpha\rmabill\rmabill101c\production
