#-------------------------------------------------------------------------------
# File 'purge_f087.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'purge_f087'
#-------------------------------------------------------------------------------

#  PURGE f087 file
#  Deletes f087 if f002-claims master does not exist for the rejects 
#
#  2013/Jan/10  MC1  - change to save original file from /charly/purge to /foxtrot/purge
#  2014/Jul/06  yas  - change to save original file from /foxtrot/purge to /charly/purge

#cd $pb_prod

Set-Location $Env:root\charly\purge

Remove-Item $pb_prod\purgef087.log *> $null

echo "Purge f087 -  STARTING - $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')" > $pb_prod\purgef087.log

&$env:QTP purge_unlof087 >> $pb_prod\purgef087.log 2> $pb_prod\purgef087.log


Set-Location $pb_data

Move-Item -Force f087_submitted_rejected_claims_hdr.dat $Env:root\charly\purge\f087_submitted_rejected_claims_hdr.dat
Move-Item -Force f087_submitted_rejected_claims_hdr.idx $Env:root\charly\purge\f087_submitted_rejected_claims_hdr.idx
Move-Item -Force f087_submitted_rejected_claims_dtl.dat $Env:root\charly\purge\f087_submitted_rejected_claims_dtl.dat
Move-Item -Force f087_submitted_rejected_claims_dtl.idx $Env:root\charly\purge\f087_submitted_rejected_claims_dtl.idx

echo "--- create files ---"
$pipedInput = @"
create file f087-submitted-rejected-claims-hdr
create file f087-submitted-rejected-claims-dtl
"@

$pipedInput | qutil++

Set-Location $Env:root\charly\purge

&$env:QTP purge_relof087 >> $pb_prod\purgef087.log 2> $pb_prod\purgef087.log


echo "Purge f087 - ENDING - $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')" >> $pb_prod\purgef087.log `
  2> $pb_prod\purgef087.log
