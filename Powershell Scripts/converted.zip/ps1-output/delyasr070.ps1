#-------------------------------------------------------------------------------
# File 'delyasr070.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'delyasr070'
#-------------------------------------------------------------------------------

Set-Location $env:application_production
Remove-Item r070_22
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #5): Unknown command.
# r070*.sf*
Set-Location $env:application_production\23
Remove-Item r070_23
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #10): Unknown command.
# r070*.sf*
Set-Location $env:application_production\24
Remove-Item r070_23
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #15): Unknown command.
# r070*.sf*
Set-Location $env:application_production\25
Remove-Item r070_23
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #20): Unknown command.
# r070*.sf*
Set-Location $env:application_production\31
Remove-Item r070_31
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #25): Unknown command.
# r070*.sf*
Set-Location $env:application_production\32
Remove-Item r070_32
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #30): Unknown command.
# r070*.sf*
Set-Location $env:application_production\33
Remove-Item r070_33
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #35): Unknown command.
# r070*.sf*
Set-Location $env:application_production\34
Remove-Item r070_34
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #40): Unknown command.
# r070*.sf*
Set-Location $env:application_production\35
Remove-Item r070_35
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #45): Unknown command.
# r070*.sf*
Set-Location $env:application_production\36
Remove-Item r070_36
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #50): Unknown command.
# r070*.sf*
Set-Location $env:application_production\37
Remove-Item r070_37
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #55): Unknown command.
# r070*.sf*
Set-Location $env:application_production\41
Remove-Item r070_41
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #60): Unknown command.
# r070*.sf*
Set-Location $env:application_production\42
Remove-Item r070_42
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #65): Unknown command.
# r070*.sf*
Set-Location $env:application_production\43
Remove-Item r070_43
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #70): Unknown command.
# r070*.sf*
Set-Location $env:application_production\44
Remove-Item r070_44
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #75): Unknown command.
# r070*.sf*
Set-Location $env:application_production\45
Remove-Item r070_45
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #80): Unknown command.
# r070*.sf*
Set-Location $env:application_production\46
Remove-Item r070_46
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #85): Unknown command.
# r070*.sf*
Set-Location $env:application_production\48
Remove-Item r070_48
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #90): Unknown command.
# r070*.sf*
Set-Location $env:application_production\80
Remove-Item r070_80
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #95): Unknown command.
# r070*.sf*
Set-Location $env:application_production\82
Remove-Item r070_82
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #100): Unknown command.
# r070*.sf*
Set-Location $env:application_production\84
Remove-Item r070_84
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #105): Unknown command.
# r070*.sf*
Set-Location $env:application_production\86
Remove-Item r070_86
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #110): Unknown command.
# r070*.sf*
Set-Location $env:application_production\87
Remove-Item r070_87
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #115): Unknown command.
# r070*.sf* 
Set-Location $env:application_production\88
Remove-Item r070_88
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #120): Unknown command.
# r070*.sf*

Set-Location $env:application_production\91
Remove-Item r070_91
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #126): Unknown command.
# r070*.sf*
Set-Location $env:application_production\92
Remove-Item r070_92
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #131): Unknown command.
# r070*.sf*
Set-Location $env:application_production\93
Remove-Item r070_93
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #136): Unknown command.
# r070*.sf*
Set-Location $env:application_production\94
Remove-Item r070_94
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #141): Unknown command.
# r070*.sf*
Set-Location $env:application_production\95
Remove-Item r070_95
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #146): Unknown command.
# r070*.sf*
Set-Location $env:application_production\96
Remove-Item r070_96
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #151): Unknown command.
# r070*.sf*
Set-Location $env:application_production\98
Remove-Item r070_96
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #156): Unknown command.
# r070*.sf*
Set-Location $env:application_production\61
Remove-Item r070_61
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #161): Unknown command.
# r070*.sf*
Set-Location $env:application_production\62
Remove-Item r070_62
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #166): Unknown command.
# r070*.sf*
Set-Location $env:application_production\63
Remove-Item r070_63
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #171): Unknown command.
# r070*.sf*
Set-Location $env:application_production\64
Remove-Item r070_64
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #176): Unknown command.
# r070*.sf*
Set-Location $env:application_production\65
Remove-Item r070_65
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #181): Unknown command.
# r070*.sf*
Set-Location $env:application_production\66
Remove-Item r070_65
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #186): Unknown command.
# r070*.sf*
Set-Location $env:application_production\71
Remove-Item r070_71
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #191): Unknown command.
# r070*.sf*
Set-Location $env:application_production\72
Remove-Item r070_72
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #196): Unknown command.
# r070*.sf*
Set-Location $env:application_production\73
Remove-Item r070_73
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #201): Unknown command.
# r070*.sf*
Set-Location $env:application_production\74
Remove-Item r070_74
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #206): Unknown command.
# r070*.sf*
Set-Location $env:application_production\75
Remove-Item r070_75
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #211): Unknown command.
# r070*.sf*
Set-Location $env:application_production\78
Remove-Item r070_78
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #216): Unknown command.
# r070*.sf*
Set-Location $env:application_production\79
Remove-Item r070_75
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*
# CONVERSION ERROR (unexpected, #221): Unknown command.
# r070*.sf*
