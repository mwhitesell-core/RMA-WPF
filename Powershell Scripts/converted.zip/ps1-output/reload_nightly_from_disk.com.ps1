#-------------------------------------------------------------------------------
# File 'reload_nightly_from_disk.com.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'reload_nightly_from_disk.com'
#-------------------------------------------------------------------------------

# 2014/Oct/01   MC1 include part4.cpio in the reload (ma folder)

echo "reload_nightly_from_disk.com"

echo ""
Get-Date

$application_root = "$Env:root\alpha\rmabill\rmabill101c"
Set-Location $env:application_root

# CONVERSION ERROR (expected, #12): compressing to cpio.
# uncompress -c < /charly/backup_transfer_area/backup_nightly_part1.cpio | cpio -icdvB
# CONVERSION ERROR (expected, #13): compressing to cpio.
# uncompress -c < /charly/backup_transfer_area/backup_nightly_part2.cpio | cpio -icdvB
# CONVERSION ERROR (expected, #14): compressing to cpio.
# uncompress -c < /charly/backup_transfer_area/backup_nightly_part3.cpio | cpio -icdvB
#MC1
# CONVERSION ERROR (expected, #16): compressing to cpio.
# uncompress -c < /charly/backup_transfer_area/backup_nightly_part4.cpio | cpio -icdvB

echo "restore is done"
Get-Date
