#-------------------------------------------------------------------------------
# File 'recoverf002.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'recoverf002'
#-------------------------------------------------------------------------------

echo "Recover the claims master file"
echo "No one must be accessing the batch control and claims files"
echo "For the clinic being processed"
echo ""
Get-Date
echo ""
&$env:COBOL r992
echo ""
Get-Date
echo ""
Get-Contents r992 | Out-Printer

echo ""
echo ""



