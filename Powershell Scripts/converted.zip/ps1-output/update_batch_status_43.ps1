#-------------------------------------------------------------------------------
# File 'update_batch_status_43.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'update_batch_status_43'
#-------------------------------------------------------------------------------

Set-Location $env:application_production\43
Remove-Item status.ls
#batch << BATCH_EXIT
&$env:cmd\status43 *> status.ls
#BATCH_EXIT
