#-------------------------------------------------------------------------------
# File 'mp_earnings.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'mp_earnings'
#-------------------------------------------------------------------------------

&$env:QTP earnings_mp
