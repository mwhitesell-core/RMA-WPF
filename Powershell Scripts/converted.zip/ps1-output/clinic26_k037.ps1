#-------------------------------------------------------------------------------
# File 'clinic26_k037.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'clinic26_k037'
#-------------------------------------------------------------------------------

Set-Location $Env:root\alpha\rmabill\rmabill101c\production

Remove-Item k037.txt *> $null

echo "Start Time is $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')"

&$env:QTP "Exec $obj/k037_code.qtc" 201704

&$env:QUIZ k037_code

Get-Contents k037.txt | Out-Printer

echo "End Time is $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')"
