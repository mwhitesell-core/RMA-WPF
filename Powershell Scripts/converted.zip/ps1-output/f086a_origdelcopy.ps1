#-------------------------------------------------------------------------------
# File 'f086a_origdelcopy.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'f086a_origdelcopy'
#-------------------------------------------------------------------------------

# f086a_origdelcopy
# 00/oct/16 B.E. - added code to keep 5 backups of files

Remove-Item f086a_orig_new_pat_ids_bkp_5.dat *> $null
Move-Item -Force f086a_orig_new_pat_ids_bkp_4.dat f086a_orig_new_pat_ids_bkp_5.dat
Move-Item -Force f086a_orig_new_pat_ids_bkp_3.dat f086a_orig_new_pat_ids_bkp_4.dat
Move-Item -Force f086a_orig_new_pat_ids_bkp_2.dat f086a_orig_new_pat_ids_bkp_3.dat
Move-Item -Force f086a_orig_new_pat_ids_bkp.dat f086a_orig_new_pat_ids_bkp_2.dat
Copy-Item f086a_orig_new_pat_ids.dat f086a_orig_new_pat_ids_bkp.dat

Remove-Item f086a_orig_new_pat_ids.dat

$pipedInput = @"
create file f086a-orig-new-pat-ids
"@

$pipedInput | qutil++

Get-Item f086a_orig_new_pat_ids.dat | % {$_.isreadonly = $false}
