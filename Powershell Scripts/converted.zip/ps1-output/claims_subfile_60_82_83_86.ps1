#-------------------------------------------------------------------------------
# File 'claims_subfile_60_82_83_86.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'claims_subfile_60_82_83_86'
#-------------------------------------------------------------------------------

##  $cmd/claims_subfile_60_82_83_86
echo ""
echo "Start Time of $env:cmd\claims_subfile_60_82_83_86 is $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')"

Get-Date
&$env:cmd\create_claims_subfile 61 20170417 201704
&$env:cmd\create_claims_subfile 62 20170417 201704
&$env:cmd\create_claims_subfile 63 20170417 201704
&$env:cmd\create_claims_subfile 64 20170417 201704
&$env:cmd\create_claims_subfile 65 20170417 201704
&$env:cmd\create_claims_subfile 66 20170417 201704
&$env:cmd\create_claims_subfile 71 20170417 201704
&$env:cmd\create_claims_subfile 72 20170417 201704
&$env:cmd\create_claims_subfile 73 20170417 201704
&$env:cmd\create_claims_subfile 74 20170417 201704
&$env:cmd\create_claims_subfile 75 20170417 201704
&$env:cmd\create_claims_subfile 82 20170417 201704
&$env:cmd\create_claims_subfile 86 20170417 201704

Set-Location $pb_prod\60

Get-Content $pb_prod\61\claims_subfile_61_201704.sfd > claims_subfile_60_201704.sfd

Get-Content $pb_prod\61\claims_subfile_61_201704.sf > claims_subfile_60_201704.sf
Get-Content $pb_prod\62\claims_subfile_62_201704.sf >> claims_subfile_60_201704.sf
Get-Content $pb_prod\63\claims_subfile_63_201704.sf >> claims_subfile_60_201704.sf
Get-Content $pb_prod\64\claims_subfile_64_201704.sf >> claims_subfile_60_201704.sf
Get-Content $pb_prod\65\claims_subfile_65_201704.sf >> claims_subfile_60_201704.sf
Get-Content $pb_prod\66\claims_subfile_66_201704.sf >> claims_subfile_60_201704.sf

Set-Location $pb_prod\70

Get-Content $pb_prod\71\claims_subfile_71_201704.sfd > claims_subfile_70_201704.sfd

Get-Content $pb_prod\71\claims_subfile_71_201704.sf > claims_subfile_70_201704.sf
Get-Content $pb_prod\72\claims_subfile_72_201704.sf >> claims_subfile_70_201704.sf
Get-Content $pb_prod\73\claims_subfile_73_201704.sf >> claims_subfile_70_201704.sf
Get-Content $pb_prod\74\claims_subfile_74_201704.sf >> claims_subfile_70_201704.sf
Get-Content $pb_prod\75\claims_subfile_75_201704.sf >> claims_subfile_70_201704.sf

echo ""
Get-Date

echo "End   Time of $env:cmd\claims_subfile_60_82_83_86 is $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')"
