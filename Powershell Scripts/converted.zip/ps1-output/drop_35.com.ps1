#-------------------------------------------------------------------------------
# File 'drop_35.com.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'drop_35.com'
#-------------------------------------------------------------------------------

# CONVERSION ERROR (expected, #1): awk.
# awk -f $cmd/drop_35.awk < $1 > $2
