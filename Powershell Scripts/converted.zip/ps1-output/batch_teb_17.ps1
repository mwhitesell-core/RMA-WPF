#-------------------------------------------------------------------------------
# File 'batch_teb_17.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'batch_teb_17'
#-------------------------------------------------------------------------------

#  Payroll Run 17 
#
Set-Location $env:application_production
Remove-Item teb_17.log *> $null
# TEB EP-NBR-CURRENT EP-NBR-START-FISCAL-YR
#batch << BATCH_EXIT
echo "Payroll Run 17 - starting - $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')" > teb_17.log

echo "--- teb_yearend1 ---" >> teb_17.log
&$env:cmd\teb1 201617 201601 >> teb_17.log 2> teb_17.log

echo "--- teb_yearend2 ---" >> teb_17.log
&$env:cmd\teb2 201617 201601 >> teb_17.log 2> teb_17.log

echo "--- u090f (QTP RUN) ---" >> teb_17.log
&$env:QTP u090f >> teb_17.log 2> teb_17.log

echo "--- teb3 ---" >> teb_17.log
&$env:cmd\teb3 201617 201601 >> teb_17.log 2> teb_17.log

echo "Payroll Run 17 - ending - $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')" >> teb_17.log
#BATCH_EXIT
