#-------------------------------------------------------------------------------
# File 'status98.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'status98'
#-------------------------------------------------------------------------------

Set-Location $env:application_production\98
echo "BEGIN NOW... $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')"
&$env:QTP u210 98000000 98ZZZZZZ
echo "ENDING.... $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')"

echo "BEGIN NOW... $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')"
&$env:QUIZ r211 98000000 98ZZZZZZ
echo "ENDING.... $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')"

Get-Contents r211 | Out-Printer
#lp status.ls
