#-------------------------------------------------------------------------------
# File 'check_f020_ohip_sin.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'check_f020_ohip_sin'
#-------------------------------------------------------------------------------

#  2015/Mar/03  MC      check_f020_ohip_sin 
#

&$env:cmd\utl0119_all.com

echo "Setup of 101c environment"
. $Env:root\macros\setup_rmabill.com  101c

echo ""
echo "Entering `'production`' directory"
Set-Location $env:application_production ; Get-Location


Remove-Item check_ohip_sin.txt, utl0f020_count.sf*, utl0f020_ohip_sin.sf* *> $null

$pipedInput = @"
create file tmp-counters-alpha
"@

$pipedInput | qutil++


&$env:QTP utl0f020_ohip_sin > check_f020_ohip_sin.log
&$env:QUIZ utl0f020_ohip_sin >> check_f020_ohip_sin.log

Get-Contents utl0f020_ohip_sin.txt | Out-Printer
