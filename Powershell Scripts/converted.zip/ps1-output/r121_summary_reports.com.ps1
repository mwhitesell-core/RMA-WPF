#-------------------------------------------------------------------------------
# File 'r121_summary_reports.com.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'r121_summary_reports.com'
#-------------------------------------------------------------------------------

# 2015/Jan/19   MC   $cmd/r121_summary_reports.com

Set-Location $env:application_root\production ; Get-Location

echo "r121_summary_reports.com  -  STARTING - $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')" > r121_summary_reports.log

# you must define the calendar year below as the parameter
&$env:cmd\r121_summary_reports 2014 >> r121_summary_reports.log

echo "r121_summary_reports.com - ENDING - $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')" >> r121_summary_reports.log
