#-------------------------------------------------------------------------------
# File 'doclist6.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'doclist6'
#-------------------------------------------------------------------------------

&$env:QUIZ doctorlist "sort on doc-dept on doc-full-part-ind on x-name" ${1} ${2} ${3} ${4} ${5} ${6}
