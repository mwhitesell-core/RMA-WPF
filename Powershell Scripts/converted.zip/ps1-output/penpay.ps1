#-------------------------------------------------------------------------------
# File 'penpay.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'penpay'
#-------------------------------------------------------------------------------

# file: ltd - upload PENPAY premiums to f114 in payroll
# 2007/jan/09 b.e. added new param to u132 call
&$env:cmd\u132 200 $1 SP
echo "Running marypenpay.."
&$env:QUIZ marypenpay
echo "Done .. paging penpay.txt report"
Get-Contents penpay.txt
