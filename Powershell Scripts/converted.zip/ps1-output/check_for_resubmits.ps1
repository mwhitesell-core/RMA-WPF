#-------------------------------------------------------------------------------
# File 'check_for_resubmits.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'check_for_resubmits'
#-------------------------------------------------------------------------------

# file: check_for_resubmits  -- alias resubmits
# purpose: update status of suspended claim to "R"esubmit
#          if accounting number already on f071
#          print report of resubmitted claims

echo "Select resubmit claims"
echo ""
&$env:QTP u714

echo ""
echo "Report selected resubmit claims"
echo ""
Remove-Item r715.txt *> $null
&$env:QUIZ r715
#lp r715.txt
