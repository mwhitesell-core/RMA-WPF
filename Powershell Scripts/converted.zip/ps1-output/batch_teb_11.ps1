#-------------------------------------------------------------------------------
# File 'batch_teb_11.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'batch_teb_11'
#-------------------------------------------------------------------------------

#  Payroll Run 11 
#
Set-Location $env:application_production
Remove-Item teb_11*.log *> $null
# TEB EP-NBR-CURRENT EP-NBR-START-FISCAL-YR
#batch << BATCH_EXIT
echo "Payroll Run 11 - starting - $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')" > teb_11.log

echo "--- teb1 ---" >> teb_11.log
&$env:cmd\teb1 201611 201601 >> teb_11.log 2> teb_11.log

echo "--- teb2 ---" >> teb_11.log
&$env:cmd\teb2 201611 201601 >> teb_11.log 2> teb_11.log

echo "--- u090f (QTP RUN) ---" >> teb_11.log
&$env:QTP u090f >> teb_11.log 2> teb_11.log

echo "Payroll Run 11 - ending - $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')" >> teb_11.log

echo "Payroll Run 11b - starting - $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')" > teb_11b.log

echo "--- teb3 ---" >> teb_11b.log
&$env:cmd\teb3 201611 201601 >> teb_11b.log 2> teb_11b.log

echo "Payroll Run 11b - ending - $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')" >> teb_11b.log
#BATCH_EXIT
