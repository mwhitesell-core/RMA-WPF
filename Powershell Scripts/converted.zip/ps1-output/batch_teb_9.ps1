#-------------------------------------------------------------------------------
# File 'batch_teb_9.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'batch_teb_9'
#-------------------------------------------------------------------------------

#  Payroll Run 9 
#
Set-Location $env:application_production
Remove-Item teb_9*.log *> $null
# TEB EP-NBR-CURRENT EP-NBR-START-FISCAL-YR
#batch << BATCH_EXIT
echo "Payroll Run 9 - starting - $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')" > teb_9.log

echo "--- teb1 ---" >> teb_9.log
&$env:cmd\teb1 201609 201601 >> teb_9.log 2> teb_9.log

echo "--- teb2 ---" >> teb_9.log
&$env:cmd\teb2 201609 201601 >> teb_9.log 2> teb_9.log

echo "--- u090f (QTP RUN) ---" >> teb_9.log
&$env:QTP u090f >> teb_9.log 2> teb_9.log

echo "Payroll Run 9 - ending - $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')" >> teb_9.log

echo "Payroll Run 9b - starting - $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')" > teb_9b.log

echo "--- teb3 ---" >> teb_9b.log
&$env:cmd\teb3 201609 201601 >> teb_9b.log 2> teb_9b.log

echo "Payroll Run 9b - ending - $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')" >> teb_9b.log
#BATCH_EXIT
