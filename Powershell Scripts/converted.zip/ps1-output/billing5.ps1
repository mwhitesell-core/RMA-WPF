#-------------------------------------------------------------------------------
# File 'billing5.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'billing5'
#-------------------------------------------------------------------------------

&$env:QUIZ billinglist "sort on doc-dept on doc-full-part-ind on doc-nbr" ${1} ${2} ${3} ${4}
