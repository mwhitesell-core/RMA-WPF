#-------------------------------------------------------------------------------
# File 'del_f010.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'del_f010'
#-------------------------------------------------------------------------------

echo "DELETE F010_PAT_MSTR"
Set-Location $pb_data
Remove-Item f010_pat_mstr*
