#-------------------------------------------------------------------------------
# File 'status91.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'status91'
#-------------------------------------------------------------------------------

Set-Location $env:application_production\91
echo "BEGIN NOW... $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')"
&$env:QTP u210 91000000 91ZZZZZZ
echo "ENDING.... $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')"

echo "BEGIN NOW... $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')"
&$env:QUIZ r211 91000000 91ZZZZZZ
echo "ENDING.... $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')"

Get-Contents r211 | Out-Printer
#lp status.ls
