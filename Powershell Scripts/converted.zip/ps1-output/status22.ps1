#-------------------------------------------------------------------------------
# File 'status22.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'status22'
#-------------------------------------------------------------------------------

echo "BEGIN NOW... $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')"
&$env:QTP u210 22000000 22ZZZZZZ
echo "ENDING.... $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')"

echo "BEGIN NOW... $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')"
&$env:QUIZ r211 22000000 22ZZZZZZ
echo "ENDING.... $(Get-Date -uformat '%Y-%m-%d %H:%M:%S')"

Get-Contents r211.txt | Out-Printer
#lp status.ls
