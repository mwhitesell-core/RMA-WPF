#-------------------------------------------------------------------------------
# File 'yearend_ar.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'yearend_ar'
#-------------------------------------------------------------------------------

Remove-Item yearendr070.ls
&$init = [scriptblock]::Create("{ Set-Location `"$(Get-Location)`" }")
Start-Job -Name "yearend_ar" -InitializationScript $init -ScriptBlock {
  & $env:cmd\yearendr070 *> yearendr070.ls
}
