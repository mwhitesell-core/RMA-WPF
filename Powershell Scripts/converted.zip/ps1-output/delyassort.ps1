#-------------------------------------------------------------------------------
# File 'delyassort.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'delyassort'
#-------------------------------------------------------------------------------

Set-Location $env:application_production
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*

Set-Location $env:application_production\23
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*

Set-Location $env:application_production\24
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*

Set-Location $env:application_production\25
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*

Set-Location $env:application_production\31
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*

Set-Location $env:application_production\32
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*

Set-Location $env:application_production\33
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*

Set-Location $env:application_production\34
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*

Set-Location $env:application_production\35
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*

Set-Location $env:application_production\36
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*

Set-Location $env:application_production\37
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*

Set-Location $env:application_production\41
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*

Set-Location $env:application_production\42
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*

Set-Location $env:application_production\43
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*

Set-Location $env:application_production\44
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*

Set-Location $env:application_production\45
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*

Set-Location $env:application_production\46
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*

Set-Location $env:application_production\48
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*

Set-Location $env:application_production\60
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*

Set-Location $env:application_production\61
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*

Set-Location $env:application_production\62
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*

Set-Location $env:application_production\63
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*

Set-Location $env:application_production\64
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*

Set-Location $env:application_production\65
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*

Set-Location $env:application_production\66
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*

Set-Location $env:application_production\70
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*

Set-Location $env:application_production\71
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_srt_work_mstr*
Remove-Item r070_work_mstr*

Set-Location $env:application_production\72
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_work_mstr*

Set-Location $env:application_production\73
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_work_mstr*

Set-Location $env:application_production\74
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_work_mstr*

Set-Location $env:application_production\75
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_work_mstr*

Set-Location $env:application_production\78
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_work_mstr*

Set-Location $env:application_production\79
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_work_mstr*

Set-Location $env:application_production\80
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_work_mstr*

Set-Location $env:application_production\82
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_work_mstr*

Set-Location $env:application_production\84
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_work_mstr*

Set-Location $env:application_production\86
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_work_mstr*

Set-Location $env:application_production\87
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_work_mstr*

Set-Location $env:application_production\88
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_work_mstr*

Set-Location $env:application_production\91
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_work_mstr*

Set-Location $env:application_production\92
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_work_mstr*

Set-Location $env:application_production\93
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_work_mstr*

Set-Location $env:application_production\94
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_work_mstr*

Set-Location $env:application_production\95
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_work_mstr*

Set-Location $env:application_production\96
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_work_mstr*

Set-Location $env:application_production\98
Remove-Item r004*.sf*
Remove-Item r004*sort*
Remove-Item r004wf
Remove-Item r051wf
Remove-Item r051_sort_work_mstr
Remove-Item r070_work_mstr*
