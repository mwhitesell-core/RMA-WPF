#-------------------------------------------------------------------------------
# File 'cleanup_governance.ps1'
# Converted to PowerShell by CORE Migration on 2017-10-01 10:16:47
# Original file name was 'cleanup_governance'
#-------------------------------------------------------------------------------

Get-Date
Set-Location $Env:root\alpha\rmabill\rmabill101c\upload

Remove-Item *140*.sf*
Remove-Item *140*.txt
Remove-Item *140*.log

Get-Date
